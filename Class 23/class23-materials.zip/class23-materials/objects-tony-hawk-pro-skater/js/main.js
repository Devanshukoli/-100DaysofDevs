//Create a Tony Hawk Pro Skater constructor that makes fighting game characters with 4 properties and 3 methods
