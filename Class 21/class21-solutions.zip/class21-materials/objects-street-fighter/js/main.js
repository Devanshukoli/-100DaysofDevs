//Create a street fighter constructor that makes fighting game characters with 4 properties and 3 methods
